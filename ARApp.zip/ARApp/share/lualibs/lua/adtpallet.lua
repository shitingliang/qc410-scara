---------------------------------------------
--更新说明：
--1.本库继承了前一版本的大部分功能，但指令用法上有差异，同时增加了部分新功能，如矩形码垛可选择码示教区外的点等；
--2.本库只开放了8个函数包括矩形码垛(Set_Plt、Get_Plt)、圆弧码垛(Set_ArcPlt、Get_ArcPlt)、
--带记忆码垛(GetPLTPos、ResetPLT)、加载配置码垛(InitPlts)、移至指定码垛点(PLTMovpToPt)；
--3.此码垛库同样需要铁电单独分配CurPltCnt[MAX_PLTS]用于保存码垛个数，目前最大支持10个码垛

-----------------------------------------------------------
local PLT				
local PtTable = {}
local AUTO_PARA={}              --带记忆码垛参数
local PLT_PARA={}               -- 矩形码垛参数
local ARCPLT_PARA={}            -- 圆弧码垛参数

--解析不码垛点数据
local function split(str,reps)
    local resultStrList = {}
    string.gsub(str,'[^'..reps..']+',function ( w )
        table.insert(resultStrList,w)
    end)
    return resultStrList
end

--table类型复制，直接“=”指引用，非赋值
local function table_cp(ori_tab)  
	if (type(ori_tab) ~= "table") then
		return nil;
	end
	local new_tab={}	
	for i,v in pairs(ori_tab) do
		local vtyp = type(v);
		if (vtyp == "table") then
			new_tab[i] = table_cp(v);
		else
			new_tab[i] = v;
		end
	end

	return new_tab;
	
end

--寻找当前码垛--
local function PltNumGet(PltName) 
	for num=1,#PLT,1 do 
		
		if PLT[num].name==PltName then
			return num
		end
		num=num+1
	end
	print "name error！"
	Exit()
end

local function plt_err(No)
	if No==1 then
		print("码垛创建失败")
	elseif No==2 then
		print("获取码垛参数超出设定范围")
	elseif No==3 then
	    print("四点矩形码垛对角点Pxy设置不合理")
	end
	Exit()
end

--[[函数名：GetRecPLTPos（内部函数）
功能:	计算标准形矩形码垛第i行，第j列，第k层的码垛点
参数:	No       码垛号/码垛名
		i,j,k   依次对应获取目标码垛的行数、列数、层数
		
返回: 	目标矩形码垛点的位置
--]]

local function GetRecPLTPos(No,i,j,k)
	local pos={}
	local temp=PLT_PARA[No]
	local pa_nLin=i/(temp[6]-1)
	local pa_nCol=j/(temp[7]-1)
	local pa_nTop=k/(temp[8]-1)
	if temp[6]==1  then  pa_nLin=0 end   --若只有一排
	if temp[7]==1  then  pa_nCol=0 end   --若只有一列
	if temp[8]==1  then  pa_nTop=0 end   --若只有一层
	
	if temp[9]==0 then --码垛顺序：X-Y-Z或者Y-X-Z
		pos.x = (temp[1].x+(temp[3].x-temp[1].x)*pa_nCol) + ((temp[2].x+(temp[4].x-temp[2].x)*pa_nCol)-(temp[1].x+(temp[3].x-temp[1].x)*pa_nCol))*pa_nLin
		pos.y = (temp[1].y+(temp[3].y-temp[1].y)*pa_nCol) + ((temp[2].y+(temp[4].y-temp[2].y)*pa_nCol)-(temp[1].y+(temp[3].y-temp[1].y)*pa_nCol))*pa_nLin
		pos.z = temp[1].z +(temp[5].z-temp[1].z)*pa_nTop
	elseif temp[9]==1  then --码垛顺序：Y-Z-X或者Z-Y-X
		pos.x = temp[1].x +(temp[5].x-temp[1].x)*pa_nTop
		pos.y = (temp[1].y+(temp[3].y-temp[1].y)*pa_nCol) + ((temp[2].y+(temp[4].y-temp[2].y)*pa_nCol)-(temp[1].y+(temp[3].y-temp[1].y)*pa_nCol))*pa_nLin
		pos.z = (temp[1].z+(temp[3].z-temp[1].z)*pa_nCol) + ((temp[2].z+(temp[4].z-temp[2].z)*pa_nCol)-(temp[1].z+(temp[3].z-temp[1].z)*pa_nCol))*pa_nLin
	
	else                       --码垛顺序：Z-X-Y或者X-Z-Y
		pos.x = (temp[1].x+(temp[3].x-temp[1].x)*pa_nCol) + ((temp[2].x+(temp[4].x-temp[2].x) *pa_nCol)-(temp[1].x+(temp[3].x-temp[1].x)*pa_nCol))*pa_nLin
		pos.y = temp[1].y +(temp[5].y-temp[1].y)*pa_nTop	
		pos.z = (temp[1].z+(temp[3].z-temp[1].z)*pa_nCol) + ((temp[2].z+(temp[4].z-temp[2].z) *pa_nCol)-(temp[1].z+(temp[3].z-temp[1].z)*pa_nCol))*pa_nLin
	end
	
	pos.c = temp[1].c
	pos.h = temp[1].h 
	return pos
end

--[[函数名：GetArcPLTPos（内部函数）
功能:	计算标准形圆弧码垛第i排，第k层的码垛点
参数:	No  码垛号/码垛名
		i,     目标处于本层的第几个位置
		k,     目标处于第几层

返回: 	码垛点的位置
--]]


local function GetArcPLTPos(No,i,k)
	local pos={}
	local flag    --顺逆圆判断
	local pa = ARCPLT_PARA[No]
    local pa_nq=i/(pa[5]-1)       --点在圆弧的位置
	local pa_nl=k/(pa[6]-1)       --高度等分占比
	
	if pa[5]==1     then  pa_nq=0 end   
	if pa[6]==1    then pa_nl=0 end   

	local r0=pa.r0
	
	local Start_Theata=pa.Szta  --圆弧与用户坐标系的x轴的起始夹角
    local End_Theata = pa.Ezta  --圆弧与用户坐标系的x轴的终止夹角
	local Delta_Theata=End_Theata-Start_Theata
	local Inc_theata	
	
	if Delta_Theata==0 then --整圆
		pa_nq=i/pa[5]       --整圆进行等分
		flag=2  
	elseif Delta_Theata>0 then   --逆圆
		flag=0  
	elseif Delta_Theata<0 then	--顺圆
		flag=1  
	end	
 
	if flag==2 then
		Inc_theata=2*math.pi*pa_nq
	elseif pa[7] ==flag and flag~=2 then   
	    Inc_theata= math.abs(Delta_Theata)*pa_nq
	elseif pa[7] ~=flag and flag~=2 then 
	    Inc_theata= (2*math.pi-math.abs(Delta_Theata))*pa_nq
	end 
	
	if pa[7] ==1 then                                              --用户设置为顺时针	
		pos.x=pa[1].x+r0*math.cos(Start_Theata-Inc_theata)
		pos.y=pa[1].y+r0*math.sin(Start_Theata-Inc_theata)
	else                                                                  --用户设置为逆时针
		pos.x=pa[1].x+r0*math.cos(Start_Theata+Inc_theata)
		pos.y=pa[1].y+r0*math.sin(Start_Theata+Inc_theata)
	end
	pos.z=pa[2].z+(pa[4].z-pa[2].z)*pa_nl
	pos.c=pa[2].c+(pa[3].c-pa[2].c)*pa_nq
	pos.h=pa[2].h
	return pos
end

----------------------------------------------------------------
--加载不码垛点，并创建配置码垛
function InitPlts(CfgName)						--读取参数文件
	CfgName = CfgName or "pallet"
	PLT = require(CfgName)
	
	----------加载不码垛点----------
	local iNum=1
	local jNum=1
	local idata=0

	for iNum=1,#PLT,1 do
		if PLT[iNum].name~=nil  then
			if PLT[iNum].pltType==0 then
				PtTable[PLT[iNum].name]={}
				for jNum=1,PLT[iNum].recPara.unpltCnt,1 do
					idata=tonumber(split(PLT[iNum].recPara.unpltPts,",")[jNum])

					PtTable[PLT[iNum].name][idata]=1
					
				end

				local tchway = PLT[iNum].recPara.teachway
				local Porg = PLT[iNum].recPara.recPts.Org
				local Px   = PLT[iNum].recPara.recPts.Px
				local Py   = PLT[iNum].recPara.recPts.Py
				local Pxy  = PLT[iNum].recPara.recPts.Pxy
				local Pz   = PLT[iNum].recPara.recPts.Pz
				local line = PLT[iNum].recPara.line
				local col  = PLT[iNum].recPara.column
				local top  = PLT[iNum].recPara.top

				Set_Plt(PLT[iNum].name,tchway,Porg,Px,Py,Pxy,Pz,line,col,top)  --创建矩形配置码垛
			else
			
				local Po	= PLT[iNum].arcPara.arcPts.P0Pos
				local Pst	= PLT[iNum].arcPara.arcPts.PstPos
				local Ped	= PLT[iNum].arcPara.arcPts.PedPos
				local Pz	= PLT[iNum].arcPara.arcPts.PzPos
				local qty   = PLT[iNum].arcPara.qty
				local layer = PLT[iNum].arcPara.layer
				local cor   = PLT[iNum].arcPara.cor
				Set_ArcPlt(PLT[iNum].name,Po,Pst,Ped,Pz,qty,layer,cor)    --创建圆弧配置码垛
			end
		end
	end

end

--------------------------------
--不码垛点判断
local function IsPtUsed(PltName,i,j)
	local strPt=string.format("%d%03d",i,j)
	local index=tonumber(strPt)
	local idata=0

	idata=PtTable[PltName][index]

	if idata ~=1 then
		idata=0	
	end
	return idata
end

--移动至指定码垛点
function PLTMovpToPt(PltName,i,j)

	local pos=Get_Plt(PltName,i,j)
	if pos==nil then 
		print "该点已设置为不码垛点，如需移动请设置保留" 
		return nil
	end
	MovJ(J3,0,"Acc=5 Spd=5")
	Delay(10)
	MovP(pos+Z(-pos.z),"Acc=5 Spd=5")
	Delay(10)
	MovP(pos,"Acc=5 Spd=5")
        sysexitmode(1)
    print "已到达指定码垛点"
end

--重置记忆码垛点
function ResetPLT(PltName,count)

	local PltNO =PltNumGet(PltName)
	publicwrite(10000+(PltNO-1),count)--写入铁电记忆码垛个数--将码垛个数置为1

end	


--[[
	函数名： GetPLTPos
	功能：	获取当前记忆码垛点，并记录下一次要码垛的点位
	用法：  flag,num,pos=GetPLTPos(PltName)
	输入：	PltName		码垛名：如PLT0
	返回值：flag为码盘的状态，0指没码满，1指码满且最后一个为码垛点，2指码满且最后一个为不码垛点
	        num为当前码垛的个数
			pos为当前码垛的位置
]]--

function GetPLTPos(PltName)
	local i,j,k,count=0,0,0,0
	local pos={}
	if AUTO_PARA[PltName]==nil then
		AUTO_PARA[PltName]={}
		local PltNO =PltNumGet(PltName)
		AUTO_PARA[PltName].count_add=10000+(PltNO-1)
		AUTO_PARA[PltName].pltType=PLT[PltNO].pltType
		AUTO_PARA[PltName].total=PLT[PltNO].total
		count = publicread(AUTO_PARA[PltName].count_add)			--读取铁电记忆码垛个数
		if count>AUTO_PARA[PltName].total	or 	count<1 or count=="nil" then
			count=1
			publicwrite(AUTO_PARA[PltName].count_add,count)	
		end
	end
	local para=AUTO_PARA[PltName]

    ::lab::	
	count = publicread(para.count_add)			--读取铁电记忆码垛个数
	
	if  para.pltType==0  then   --设置为矩形码垛
		local tmp=PLT_PARA[PltName]
			
		i = ((count-1)%(tmp[6]*tmp[7]))%tmp[6]
		j = math.floor((count-1)%(tmp[6]*tmp[7])/tmp[6])
		k = math.floor((count-1)/(tmp[6]*tmp[7]))
		
		if 0 == IsPtUsed(PltName,i+1,j+1,k+1)  then          
           pos=GetRecPLTPos(PltName,i, j, k)
		else
			count=count+1			--当前个数
			publicwrite(para.count_add,count)--写入铁电记忆码垛个数
			if count>para.total then  return  2  end
			goto lab
		end
		
	else                  --设置为圆形码垛
     	local tmp=ARCPLT_PARA[PltName]

		i = (count-1)%tmp[5]
		k = math.floor((count-1)/tmp[5])   

        pos=GetArcPLTPos(PltName, i, k)
		
    end
	
    count=count+1			--当前个数
	publicwrite(para.count_add,count)--写入铁电记忆码垛个数
	if count > para.total then
		return 1,count-1,pos
	else 
		return 0,count-1,pos
	end

end

--[[配置码垛示例：
local posready = p1              --待机点
local quliao = p2                 --取料点
local flag,num
local pos ={}
InitPlts()                  --加载默认配置文件
MArchP(posready,0,10,10)    --运动到待机点

while true do
	MArchP(quliao,0,10,10)        --运动到取料点
	DO(1,ON)
	Delay(150)
	flag,num,pos =GetPLTPos("PLT0")  --获取码垛点
	if flag == 0 then       --未码完
		MArchP(pos,0,10,10)     --运动到码垛点
		DO(1,OFF)
		Delay(150)
	elseif flag ==1 then  --码满
		MArchP(pos,0,10,10)     --运动到码垛点
		DO(1,OFF)
		Delay(150)
		ResetPLT("PLT0",1)  --重置码垛
	elseif flag==2 then --码盘的最后一个点为不码垛点，码完的返回值
		ResetPLT("PLT0",1)  --重置码垛
	end
end
--]]
	
-----------------------------------------------------------------------------------

--[[
	函数名： Set_ArcPlt
	功能：	设置圆形码垛
	输入：	No,		码垛号，对应当前码垛
			p0,		码垛原点，即圆形码垛第一层的圆心位置
			pst,	码垛第一层起点位置
			ped,	码垛第一层终点位置
            pz，    码垛最后一层起点位置
			qty,	法向方向码垛等分个数
			layer， 码垛层数
			cor，   码垛方向，即逆顺时针(0为逆时针，1为顺时针)
    用法： 设置平面整圆码垛                       Set_ArcPlt(No,p0,pst,num,cor) 
	       设置平面圆弧码垛（包括整圆）            Set_ArcPlt(No,p0,pst,ped,num,cor)
		   设置空间圆弧码垛（在平面圆弧加了层方向） Set_ArcPlt(No,p0,pst,ped,pz,num,layer,cor)

	返回：	无返回值
]]--

function Set_ArcPlt(No,p0,pst,ped,pz,qty,layer,cor)
	
    local para=table_cp({p0,pst,ped,pz,qty,layer,cor})
	
	if para[5]==nil then
		para[7]=para[4]
		para[6]=1
		para[5]=para[3]
		para[4]=para[2]
		para[3]=para[2]

	elseif para[6]==nil then	
		para[7]=para[5]
		para[6]=1
		para[5]=para[4]
		para[4]=para[3]
	elseif para[4].x==0 and para[4].y==0 and para[4].z==0 then
		para[4]=para[2]
		if para[3].x==0 and para[3].y==0 and para[3].z==0 then
			para[3]=para[2]
		end
	end

	local zta0=math.atan2(para[1].y,para[1].x)
	local zta1=zta0-math.pi
	if zta0< 0 then zta1=zta0+math.pi end
		
	para.r0=math.sqrt(math.pow(para[1].x-para[2].x,2)+math.pow(para[1].y-para[2].y,2))
	local dangerPt0={x=para[1].x+para.r0*math.sin(zta0),y=para[1].y+para.r0*math.cos(zta0),z=para[1].z,c=para[1].c}
	local dangerPt1={x=para[1].x-para.r0*math.sin(zta0),y=para[1].y-para.r0*math.cos(zta0),z=para[1].z,c=para[1].c}
	para.Szta=math.atan2(para[2].y-para[1].y,para[2].x-para[1].x)    --圆弧与用户坐标系的x轴的起始夹角
	para.Ezta = math.atan2(para[3].y-para[1].y,para[3].x-para[1].x)  --圆弧与用户坐标系的x轴的终止夹角

	if para[7] ~=0 then para[7] =1 end  --cor为非0，强制转换为顺时针方向
		
	ARCPLT_PARA[No] = para
	for i=1,para[5],1 do                --判断码垛点能否到达
		pos=GetArcPLTPos(No, i, 1)
		if 1==Targetok(pos) then
			print("圆弧码垛"..No.."区域不可到达") 
			Exit() 
		end
	end
end

--[[
	函数名： Get_ArcPlt
	功能：	获取圆形码垛目标位置
	输入：	No,		码垛号//码垛名，对应当前码垛
			p_1,		目标处于本层的第几个位置
            p_2，       目标处于第几层
	用法：  
	        以码垛序号获取码垛      pos=Get_ArcPlt(No,p_1)
			以第几个位置第几层获取码垛  pos=Get_ArcPlt(No,p_1,p_2)
	返回：	若目标点在示教区内则返回目标位置，否则返回nil
]]--

function Get_ArcPlt(No,p_1,p_2)
	local pos={}
	local pa = ARCPLT_PARA[No]
	local num,i,k
    
	if pa ==nil  then  plt_err(1)  end
   
	if  p_2==nil then  --平面圆形码垛
		num=p_1-1
		i = num%pa[5]
		k = math.floor(num/pa[5])   
	else        --空间圆形码垛
		i=p_1-1
		k=p_2-1
	end	

	if i < 0 or i > pa[5]-1  or k < 0 or k > pa[6]-1  then  plt_err(2) end
		
	pos=GetArcPLTPos(No, i, k) 
	
	return pos
	
end

--[[圆弧编程码垛示例：
SetU(1)       --以圆形码盘上的六个点建立的圆形用户坐标系1
local posready = p1              --待机点（用户1下示教）
local place = p2                  --放料点（用户1下示教）
local Arc_org = p5     --码垛圆心位置（用户1原点）
local Arc_start = p6          --码垛第一层起点位置（用户1下示教）
local Arc_end = p7           --码垛第一层终点位置（用户1下示教）
local Arc_layer = p9          --码垛最后一层终点位置（用户1下示教）
local qty = 7            --起点(p2)和终点(p3)之间(逆时针)的等分数7
local layer=3           --圆弧码垛层数（p2点与p4点之间的间隔数）
local cor =0          --圆弧码垛的方向（逆时针）
--Set_ArcPlt(1,Arc_org,Arc_start,Arc_end,qty,cor) --设置单层圆弧码垛
Set_ArcPlt(1,Arc_org,Arc_start,Arc_end,Arc_layer,qty,layer,cor) --设置多层圆弧码垛

MArchP(posready,0,10,10)
while true do
	for j =1,layer do
		for i =1,qty do
			pos = Get_ArcPlt(1,i,j) --获取码垛点位，也可按码垛序号(Get_ArcPlt(1,num))获取
			print (pos.x,pos.y,pos.z,pos.c)                        
			MArchP(pos,0,10,10)        --运动到码垛位置
			Delay(50)
			MArchP(place,0,10,10)       --运动到放料点
	    end
	end 
end 
--]]
----------------------------------------------------------------------------

--[[
	函数名： Set_Plt
	功能：	设置矩形码垛
	输入：	No,		码垛号，对应当前码垛
			tchway,	码垛平面的示教方式，即3点法或者4点法
	        org，    码垛原点，即矩形码垛的第一个点
			px,		码垛第一层行方向的最后一个点
			py,		码垛第一层列方向的最后一个点
			pxy,	码垛第一层起点对角方向的最后一个点
            pz，    码垛最后一层第一个码垛点的位置
			nx,		行方向码垛的个数
			ny，    列方向码垛的个数
			nz，    层方向码垛的个数
    用法：
	        三点设置平面码垛     Set_Plt(No,3,org,px,py,nx,ny)
            三点设置空间码垛     Set_Plt(No,3,org,px,py,pz,nx,ny,nz)
	        四点设置平面码垛     Set_Plt(No,4,org,px,py,pxy,nx,ny)
            四点设置空间码垛     Set_Plt(No,4,org,px,py,pxy,pz,nx,ny,nz)
	
	返回：	无返回值
]]--


function Set_Plt(No,tchway,org,px,py,pxy,pz,nx,ny,nz)
     
    local para=table_cp({org,px,py,pxy,pz,nx,ny,nz})
	local aotu_sign,aotu={},{}  --用于判断矩形码垛的凹凸性
	local Abs=math.abs
	local  x_diff=(Abs(para[2].x-para[1].x)+Abs(para[3].x-para[2].x)+Abs(para[3].x-para[1].x))
	local  y_diff=(Abs(para[2].y-para[1].y)+Abs(para[3].y-para[2].y)+Abs(para[3].y-para[1].y))
	local  z_diff=(Abs(para[2].z-para[1].z)+Abs(para[3].z-para[2].z)+Abs(para[3].z-para[1].z))
	
	if z_diff==math.min(x_diff,y_diff,z_diff) then     --码垛第一层在XY平面
		para[9]=0
	elseif x_diff==math.min(x_diff,y_diff,z_diff) then --码垛第一层在YZ平面
		para[9]=1
	else               --码垛第一层在ZX平面
		para[9]=2
	end
	
	if tchway == 3 then     --三点矩形码垛

		if para[6]==nil then  --外部三点码垛，不含pz（3点+2个行列数）
			para[8]=1
			para[7]=para[5]
			para[6]=para[4]
			para[5]=para[1]
		elseif para[8]==nil then  --外部三点码垛，含pz（4点+3个行列数）
			para[8]=para[7]
			para[7]=para[6]
			para[6]=para[5]
			para[5]=para[4]
		elseif  para[5].x==0 and para[5].y==0 and para[5].z==0 then --配置三点码垛，pz为默认值
			para[5]=para[1]
		end
		
		para[4]={}
		para[4].c=para[1].c
		para[4].h=para[1].h
		if para[9]==0 then --码垛第一层在XY平面
			para[4].x=para[2].x-para[1].x+para[3].x
			para[4].y=para[2].y-para[1].y+para[3].y
			para[4].z=para[1].z

		elseif para[9]==1 then --码垛第一层在YZ平面
			para[4].x=para[1].x
			para[4].y=para[2].y-para[1].y+para[3].y
			para[4].z=para[2].z-para[1].z+para[3].z

		else               --码垛第一层在ZX平面
			para[4].x=para[2].x-para[1].x+para[3].x
			para[4].y=para[1].y
			para[4].z=para[2].z-para[1].z+para[3].z

		end 
			
	elseif tchway == 4 then     --四点矩形码垛
		if para[7]==nil then  --外部四点码垛，不含pz（4点+2个行列数）
			para[8]=1
			para[7]=para[6]
			para[6]=para[5]
			para[5]=para[4]
		elseif para[5].x==0 and para[5].y==0 and para[5].z==0 then --配置四点码垛，pz为默认值
			para[5]=para[1]
		end 

		if para[9]==0 then --码垛第一层在XY平面
			aotu_sign[1]=(para[4].y-para[1].y)*para[2].x-(para[4].x-para[1].x)*para[2].y+para[4].x*para[1].y-para[1].x*para[4].y
			aotu_sign[2]=(para[4].y-para[1].y)*para[3].x-(para[4].x-para[1].x)*para[3].y+para[4].x*para[1].y-para[1].x*para[4].y	
			
			aotu_sign[3]=(para[3].y-para[2].y)*para[1].x-(para[3].x-para[2].x)*para[1].y+para[3].x*para[2].y-para[2].x*para[3].y			
			aotu_sign[4]=(para[3].y-para[2].y)*para[4].x-(para[3].x-para[2].x)*para[4].y+para[3].x*para[2].y-para[2].x*para[3].y	
	    
		elseif para[9]==1 then --码垛第一层在YZ平面
			aotu_sign[1]=(para[4].z-para[1].z)*para[2].y-(para[4].y-para[1].y)*para[2].z+para[4].y*para[1].z-para[1].y*para[4].z
			aotu_sign[2]=(para[4].z-para[1].z)*para[3].y-(para[4].y-para[1].y)*para[3].z+para[4].y*para[1].z-para[1].y*para[4].z	
			
			aotu_sign[3]=(para[3].z-para[2].z)*para[1].y-(para[3].y-para[2].y)*para[1].z+para[3].y*para[2].z-para[2].y*para[3].z			
			aotu_sign[4]=(para[3].z-para[2].z)*para[4].y-(para[3].y-para[2].y)*para[4].z+para[3].y*para[2].z-para[2].y*para[3].z	

		else                  --码垛第一层在ZX平面
			aotu_sign[1]=(para[4].x-para[1].x)*para[2].z-(para[4].z-para[1].z)*para[2].x+para[4].z*para[1].x-para[1].z*para[4].x 
		    aotu_sign[2]=(para[4].x-para[1].x)*para[3].z-(para[4].z-para[1].z)*para[3].x+para[4].z*para[1].x-para[1].z*para[4].x		
			
			aotu_sign[3]=(para[3].x-para[2].x)*para[1].z-(para[3].z-para[2].z)*para[1].x+para[3].z*para[2].x-para[2].z*para[3].x		
			aotu_sign[4]=(para[3].x-para[2].x)*para[4].z-(para[3].z-para[2].z)*para[4].x+para[3].z*para[2].x-para[2].z*para[3].x	

		end
		aotu[1]=aotu_sign[1]*aotu_sign[2]   
		aotu[2]=aotu_sign[3]*aotu_sign[4]   
		aotu[3]=math.abs(aotu_sign[1])+math.abs(aotu_sign[2])
		aotu[4]=math.abs(aotu_sign[3])+math.abs(aotu_sign[4]) 

		if (aotu[1] >=0 and aotu[3] >0.1) or (aotu[2] >=0 and aotu[4] >0.1)  then	plt_err(3) end  --矩形码垛为凹四边形，提示错误
		
	end
	
	if Targetok(para[1])+Targetok(para[2])+Targetok(para[3])+Targetok(para[4])+Targetok(para[5]) >0 then  
		print("矩形码垛"..No.."区域不可到达") 
		Exit() 
	end
	PLT_PARA[No]=para
end

--[[
	函数名： Get_Plt
	功能：	获取矩形码垛目标位置
	输入：	No,		码垛号/码垛名，对应当前码垛
	        p_1,    获取第几行
			p_2,    获取第几列
			p_3，   获取第几层
			"outside",获取码垛示教区外点的关键字（当然也可获取示教区内的点）
    用法： 
	        按码垛序号获取平面/空间码垛（只能获取示教区域内的点）      pos=Get_Plt(No,p_1)
			按行列获取平面码垛（只能获取示教区域内的点）               pos=Get_Plt(No,p_1,p_2)
			按行列获取平面码垛外的点（可获取示教区内外的点）           pos=Get_Plt(No,p_1,p_2,"outside")
			按行列高获取空间码垛（只能获取示教区域内的点）             pos=Get_Plt(No,p_1,p_2,p_3)
			按行列高获取空间码垛（可获取示教区内外的点）               pos=Get_Plt(No,p_1,p_2,p_3,"outside")
			
	返回：	若为编程码垛则返回目标位置
	        若为配置码垛且目标点位为可码垛点则返回目标位置，否则返回nil
]]--

function Get_Plt(No,p_1,p_2,p_3,p_4)
	local pos={}
	local temp=PLT_PARA[No]
    local i,j,k,num

	if temp ==nil  then plt_err(1) end

	if  p_2==nil then  --输入码垛的序列号
		num = p_1-1
		i = num%(temp[6]*temp[7])%temp[6]
		j = math.floor((num%(temp[6]*temp[7]))/temp[6])
		k = math.floor(num/(temp[6]*temp[7]))
	elseif p_3==nil or p_3=="outside" then    --输入码垛的行列
		i=p_1-1
		j=p_2-1
		k=0 
	elseif p_4==nil or p_4=="outside" then    --输入码垛的行列高  
		i=p_1-1
		j=p_2-1
		k=p_3-1
	
	end
	
	if  p_3~="outside" and  p_4~="outside" and (i<0 or i>temp[6]-1 or j<0 or j>temp[7]-1  or k<0 or k>temp[8]-1) then  plt_err(2) end
	
	if PtTable[No] == nil or (0 == IsPtUsed(No,i+1,j+1,k+1))  then            

		pos=GetRecPLTPos(No,i,j,k)
	else
		return nil
	end
	
	return pos

end

--[[矩形编程码垛示例：
local posready = p1              --待机点
local place = p2                 --放料点
local org = p3  				 --码垛原点
local px = p4  				--码垛行方向最后一个
local py = p5   			    --码垛列方向最后一个
local pxy = p6                 --码垛原点对角线的最后一个
local nx,ny = 5,4               --码垛的行数，列数
local pos = {}
Set_Plt(1,4,org, px,py ,pxy,nx,ny)   --设置单层码垛
--Set_Plt(1,4,org, px,py,pxy,pz,nx,ny,nz)   --设置多层码垛
MArchP(posready,0,10,10)    --运动到待机点
while true do
	for i =1, nx*ny do 
	    pos = Get_Plt(1,i)   --获取码垛点位，也可按行列号(Get_Plt(1,i,j))获取
	    print(pos.x,pos.y,pos.z,pos.c)
	    MArchP(pos,0,10,10)  --运动到码垛位置
		Delay(50)
		MArchP(place,0,10,10)    --运动到放料点
	end
end
--]]
