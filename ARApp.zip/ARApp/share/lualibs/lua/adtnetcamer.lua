local socket = require("socket")
local CAM={}
local NetDescribe={}

function InitParam(Filename)
	local num=0
	
	CAMTemp=require(Filename)	
	if CAM ~= nil then 
		num=#CAM
	end
--	print("CAMTemp:",#CAMTemp)
	if CAMTemp~=nil then
		local i=1
		while CAMTemp[i] do
			CAM[num+i]=CAMTemp[i]
			i=i+1				
		end
	end
--	print("NUM:",#CAM)
end

function GetParamNum(Name)
	local length=#CAM
	
	for num=1,length,1 do	
		if CAM[num].name==Name then
			return num
		end
	end	
	return nil
end

--[[------------------------------------------------
	功能:	多组数据处理函数
	参数:	cmm_str  字符串格式数据
			form  数据格式,例如 XX,YY,CC;
	返回: 	nil 格式错误,正确返回数据帧数和数据
--]]------------------------------------------------
function GetCmmData(cmm_str,form)
	
	if UserDataProc then
		return UserDataProc(cmm_str,form)
	end
	local mode="[+-]?%%d+%%.?%%d*"
	cmm_str=string.gsub(cmm_str," ","")
	local StrLen=string.len(cmm_str)
	local _,e = string.find(form,"XX")
	local separate=string.sub(form,e+1,e+1)
	local temp
	form=string.gsub(string.gsub(string.gsub(form,"XX",mode), "YY",mode),"CC",mode)
	
	
	local N1=string.find(form,"N1") --
	if N1 then	
		form=string.gsub(form,"N1",mode)
	end
	local N2=string.find(form,"N2") --
	if N2 then	
		form=string.gsub(form,"N2",mode)
	end
	local N3=string.find(form,"N3") --
	if N3 then	
		form=string.gsub(form,"N3",mode)
	end
	
	local No=string.find(form,"NO") --查找模板号
	if No then	
		form=string.gsub(form,"NO","%%w+")
	end

	local state = string.find(form,"STA")
	if state then
		form=string.gsub(form,"STA","%%w+")
	end
	
	local i,n,k,l,pos=1,1,1,0,{str=cmm_str}
	
	k,n = string.find(cmm_str,separate,n) --查找第一个逗号前的标识符

	if k then
		local head = string.sub(cmm_str,1,k-1)
		
		local a1,b1 = string.find(head,"(%w+)",1)
		local a2,b2 = string.find(head,"(%d+)",1)
		if a1 then
			if b1 == k - 1 and (a2==nil or (b2-a2 + 1) )~= B1 then
					n = n + 1
					temp = StrLen
					StrLen = StrLen - k
					pos.head = head
			else
				k = 1
				n = 1
			end
		else
			k = 1
			k = 1
		end
	else
		k = 1
		n = 1
	end
	local first = 1
	local start_pos=n
	mode="([+-]?%d+%.?%d*)"
	while 1 do	
		k,n=string.find(cmm_str,form,n)	
		if n==nil or k==nil or (first == 1 and start_pos ~= k ) then			
			if first== 1 and pos.head then
				n = 1
				pos.head = nil
				StrLen = temp
				first = 0
				k,n=string.find(cmm_str,form,n)
				if n==nil or k==nil then 
					break  
				end
			else
				break
			end
		end
		first = 0
		l=l+n-k+1
		local x,y,z,a,b,c,no
		z=""
		a=""
		b=""
		pos[i]={}
		if No then
			_,k,pos[i].NO=string.find(cmm_str,"(%w+)",k)
			k = k+1
		end
		_,k,x=string.find(cmm_str,mode,k)
		if x==nil then return nil end
		_,k,y=string.find(cmm_str,mode,k+1)
		if y==nil then return nil end	
				
		_,k,c=string.find(cmm_str,mode,k+1)
		if c==nil then return nil end
		
		if N1 then
			_,k,z=string.find(cmm_str,mode,k+1)
			if z==nil then return nil end
		end		
		if N2 then
			_,k,a=string.find(cmm_str,mode,k+1)
			if a==nil then return nil end
		end	
		if N3 then
			_,k,b=string.find(cmm_str,mode,k+1)
			if b==nil then return nil end
		end	
		if state then
			_,k,pos[i].STA=string.find(cmm_str,"(%w+)",k+1)
			k = k+1
		end
		pos[i][1],pos[i][2],pos[i][3],pos[i][4],pos[i][5],pos[i][6]=tonumber(x),tonumber(y),tonumber(c),tonumber(z),tonumber(a),tonumber(b)
		pos[i].x,pos[i].y,pos[i].c,pos[i].N1,pos[i].N2,pos[i].N3 = pos[i][1],pos[i][2],pos[i][3],pos[i][4],pos[i][5],pos[i][6]
		n,i= n+1,i+1
	end
	if l ~= StrLen then 
		if string.byte(cmm_str,StrLen) == 0 then
			cmm_str=string.sub(cmm_str,1,StrLen-1)
			StrLen = StrLen-1
		end
		if l ~= StrLen then
			if  (string.byte(cmm_str,StrLen) == 0x0a and
				string.byte(cmm_str,StrLen-1) == 0x0d) then
				cmm_str=string.sub(cmm_str,1,StrLen-2)
				StrLen = StrLen-2
			elseif (string.byte(cmm_str,StrLen) == 0x0a or
			   string.byte(cmm_str,StrLen) == 0x0d)  then
				cmm_str=string.sub(cmm_str,1,StrLen-1)
				StrLen = StrLen-1
			end
		end
		if l ~= StrLen then return nil end
	end
	return i-1,pos
end


--[[
	函数名：SysNetSet
	功能：	网络初始化
	输入：	netMode：网络类型：0为TCP_Server，1为TCP_Client，2为UDP_Server，3为UDP_Client
			host：对方设备IP地址，若为TCP_Server，host为监听号
			port：对方设备端口号
	输出：	NetDescribe:网络描述符
			sta：0：创建成功 1：超时失败
]]--
function SysNetSet(netMode,host,port,timeout)
	local   NO=GetParamNum(Name)
	local 	CameraPara=CAM[NO]
	
	local	time1=systime()	
	local	client,client_tab={}
	
	if netMode==0 then			--0为TCP_Server	
		print("机器人作为服务器")	

		while (systime()-time1)<timeout or timeout==0 do
			client_tab=socket.getacceptsock(host,0)
			if client_tab~=nil then
				for conn_table, client_table in pairs(client_tab) do		
					client = client_table[1]      --socket		
					--conn_count = client_table[2]  --ip     
				end	
				if client ~= nil then
					recvt, sendt, status = socket.select({client}, nil, 0)
					if #recvt > 0 then
						receive, receive_status = client:receive()
					end
					return client,0
				end
			end				
		end
		print("获取连接对象超时！")
		return nil,1
	
	elseif netMode==1 then		--1为TCP_Client
	    tcp_client = socket.tcp()
		print("正在连接TCP服务器...")		
		while (systime()-time1)<timeout or timeout==0 do
			tcp_client:settimeout(500)
			state = tcp_client:connect(host, port)  --与TCP服务器建立连接
			if state then
				print("已连接TCP服务器!")
				tcp_client:settimeout(0)
				return tcp_client,0
			else 
				tcp_client:close()
			end
		end
		print("连接服务器超时！")	
		return nil,1
	elseif netMode==2 then		--2为UDP_Server	
		local	port1,ip=GetIPPort()		--获取本机IP PORT
		local	host1=string.format("%d.%d.%d.%d",ip[1],ip[2],ip[3],ip[4])
	    udp_server = socket.udp()
		udp_server:settimeout(0)
		udp_server:setsockname(host1, port1)
		return udp_server,0
	elseif netMode==3 then		--3为UDP_Client
	    udp_client = socket.udp()
		udp_client:settimeout(0)
		udp_client:setpeername(host, port)  --与udp服务器建立连接
		return udp_client,0
	end	
end
--[[
	函数名：SysNetGet
	功能：	网络接收
	输入：	NetMode：网络类型：0为TCP_Server，1为TCP_Client，2为UDP_Server，3为UDP_Client
			NetDescribe:网络描述符
			blockMode：0为堵塞，1为非堵塞
			blockTime：堵塞时间
	输出：	receive：接收到的字符
			sta：0：接收成功 1：断线或超时
]]--
function SysNetGet(netMode,NetDescribe,blockMode,blockTime)
	local receive
	local time1=systime()
	
	waitpos()		
	
	if netMode==0 then			--0为TCP_Server						
		while 1 do
			recvt, sendt, status = socket.select({NetDescribe}, nil, 0)
			if #recvt > 0 then
				receive, receive_status = NetDescribe:receive()
				if receive_status == "closed" then
					NetDescribe:close() 
					print("当前连接已断开或接收数据超时！")
					return nil,1
				elseif receive_status == "timeout" then
					print("当前连接已断开或接收数据超时！")
					return nil,1	
				end	
				if receive then				
					break
				end
			end
			if blockMode ==0 then
				if blockTime>0 and (systime()-time1)>blockTime then
					print("当前连接已断开或接收数据超时！")
					return nil,1	
				end
			else
				break
			end
		end		
	elseif netMode==1 then		--1为TCP_Client				
		while 1 do
			recvt, sendt, status = socket.select({NetDescribe}, nil, 0)
			
			if #recvt > 0 then	
				receive, receive_status = NetDescribe:receive("*a")
			--	print("receive_status:",receive_status)
				if receive_status == "closed" then
					print("当前连接已断开或接收数据超时！")
					return nil,1						
				elseif receive_status == "timeout" then
					print("当前连接已断开或接收数据超时！")
					return nil,1	
				end	
				
				if receive then				
					break
				end
			end
			if blockMode ==0 then
				if blockTime>0 and (systime()-time1)>blockTime then
					print("当前连接已断开或接收数据超时！")
					return nil,1	
				end
			else
				break
			end
		end
	elseif netMode==2 then		--2为UDP_Server		
		while 1 do
			receive,receip,receport = NetDescribe:receivefrom()--(接收数据前，服务端需向客户端先发送数据)

			if (receive and receip and receport) then			
				break
			else
				if blockMode ==0 then
					if blockTime>0 and (systime()-time1)>blockTime then
						print("当前连接已断开或接收数据超时！")
						return nil,1	
					end
				else
					break
				end
			end
		end
	elseif netMode==3 then		--UDP_Client(接收数据前，客户端需向服务端先发送数据)
		while 1 do
			receive = NetDescribe:receive()
			if receive then				
				break
			else
				if blockMode ==0 then
					if blockTime>0 and (systime()-time1)>blockTime then
						print("当前连接已断开或接收数据超时！")
						return nil,1	
					end
				else
					break
				end
			end
		end			
	end
	if #receive>0 then 
		return receive,0
	end
	return nil,1
end

--[[
	函数名：SysNetSend
	功能：	发送网络数据
	输入：	buff: 要发送的数据
			NetMode：网络类型：0为TCP_Server，1为TCP_Client，2为UDP_Server，3为UDP_Client
			NetDescribe:网络描述符
			ip, port
	输出：	sta：0：发送成功 1：断线或超时
]]--
function SysNetSend(buff,netMode,NetDescribe,ip,port)
	local receive, receive_status=0
	
	waitpos()
	
	if netMode==0 then		--0为TCP_Server
		receive, receive_status=NetDescribe:send(buff)
		if receive_status == "closed" then
			print("当前连接已断开或发送数据超时！")
			return 1	
		elseif receive_status == "timeout" then
			print("当前连接已断开或发送数据超时！")
			return 1	
		end
	elseif netMode==1 then		--1为TCP_Client		
		receive, receive_status=NetDescribe:send(buff)
		if receive_status == "closed" then
			print("当前连接已断开或发送数据超时！")
			return 1	
		elseif receive_status == "timeout" then
			print("当前连接已断开或发送数据超时！")
			return 1	
		end
	elseif netMode==2 then			--2为UDP_Server		
		NetDescribe:sendto(buff,ip,port)
	elseif netMode==3 then		--3为UDP_Client		
		NetDescribe:setpeername(ip,port)
		NetDescribe:send(buff)
	end
	return 0
end
--[[
	函数名：InitNet
	功能：	初始化网络
	输入：	Name：配置界面生成的名称
	输出：	sta：0：创建成功 1：超时失败
]]--
function InitNet(Name)
	local   No=GetParamNum(Name)
	local 	Param=CAM[No]
	local	sta

	if Param.netMode==0 then	--0为TCP_Server
		NetDescribe[No],sta=SysNetSet(Param.netMode,Param.lisionNo,nil,Param.timeout)
	else
		NetDescribe[No],sta=SysNetSet(Param.netMode,Param.ip,Param.port,Param.timeout)
	end
		
	return sta
end
--[[
	函数名：ReadNet
	功能：	读取网络
	输入：	Name：配置界面生成的名称
	输出：	str：接收到的字符
			sta：0：成功 1：断线或超时
]]--
function ReadNet(Name)
	local   No=GetParamNum(Name)
	local 	Param=CAM[No]
	local	str,sta
	
	str,sta=SysNetGet(Param.netMode,NetDescribe[No],Param.blockMode,Param.blockTime)
	
	return str,sta
end
--[[
	函数名：SendNet
	功能：	发送数据到网络
	输入：	Name：配置界面生成的名称
			buff：要发送的字符
	输出：	sta：0：成功 1：断线或超时
]]--
function SendNet(Name,buff)
	local   No=GetParamNum(Name)
	local 	Param=CAM[No]
	local	sta
	
	sta=SysNetSend(buff,Param.netMode,NetDescribe[No],Param.ip,Param.port)

	return sta
end

--[[-------------------------------------------------
	函数名：CCDrecv
	功能：	相机数据接收+坐标转换+字符串解析
	输入：	CamName	:	视觉名，在UI配置时会生成
	输出：	n	 :	位置坐标个数	
			data :	绝对位置坐标--x,y,c
			err_net：0为成功，1：断线或超时 2：字符匹配错误，无法解析
]]----------------------------------------------------	
function CCDrecv(CamName)
	local   CamNo=GetParamNum(CamName)
	local 	CameraPara=CAM[CamNo]
	local	X=	{	CameraPara.xPts.x1,CameraPara.xPts.x2,CameraPara.xPts.x3,CameraPara.xPts.x4,
					CameraPara.xPts.x5,CameraPara.xPts.x6,CameraPara.xPts.x7,CameraPara.xPts.x8,
					CameraPara.xPts.x9,CameraPara.xPts.x10,CameraPara.xPts.x11,CameraPara.xPts.x12,
					CameraPara.xPts.x13,CameraPara.xPts.x14,CameraPara.xPts.x15,CameraPara.xPts.x16,
					CameraPara.xPts.x17,}
	local	RecBuf={}
	local	err_net=0	
	
	RecBuf,err_net=SysNetGet(CameraPara.netMode,NetDescribe[CamNo],CameraPara.blockMode,CameraPara.blockTime)
	
	if err_net==0 then								
		local n,data = GetCmmData(RecBuf,CameraPara.recvForm)	--字符串处理	
		
		if data then	
			local pos={x=0,y=0,z=0,c=0,h=0}			
			if CameraPara.IsRobotCalib==1 then
				for i=1,n do	
					if data[i][1]~=0 or data[i][2]~=0 then
						local VisData
						if CameraPara.visType==1 and CameraPara.calibType==1 and CameraPara.fixType==0 then	
							VisData=VisToRobJ2({x=data[i].x,y=data[i].y,c=data[i].c},X,CameraPara.pixelIndex,CameraPara.UserPixelX,CameraPara.UserPixelY)						
						else
							--[[if CameraPara.visType==1 and CameraPara.calibType==1 and CameraPara.fixType==1 then
								VisData=VisToRobJ4({x=data[i].x,y=data[i].y,c=data[i].c},X,CameraPara.pixelIndex,CameraPara.UserPixelX,CameraPara.UserPixelY)
							else
								VisData=VisToRob({x=data[i].x,y=data[i].y,c=data[i].c},X,CameraPara.pixelIndex,CameraPara.UserPixelX,CameraPara.UserPixelY)
							end--]]
							VisData=VisToRob({x=data[i].x,y=data[i].y,c=data[i].c},X,CameraPara.pixelIndex,CameraPara.UserPixelX,CameraPara.UserPixelY)
						end
						pos.x=VisData.x
						pos.y=VisData.y
						pos.c=VisData.c
						
						if CameraPara.visType==1 then --若为动态视觉
							pos=GetDynViewPos(CameraPara.fixType,CameraPara.camTCrd,VisData)
						end
						VisData=nil
					else
						x=0
						y=0
						c=0
					end
					data[i][1]=pos.x
					data[i][2]=pos.y
					data[i][3]=pos.c			
					data[i].x=pos.x
					data[i].y=pos.y
					data[i].c=pos.c
				end
				pos=nil
			else
				if CameraPara.visType==1 then --若为动态视觉
					local VisData={x=0,y=0,z=0,c=0,h=0}
					for i=1,n do
						VisData.x=data[i][1]
						VisData.y=data[i][2]
						VisData.z=data[i][3]
						
						pos=GetDynViewPos(CameraPara.fixType,CameraPara.camTCrd,VisData)
						
						VisData=nil						
						
						data[i][1]=pos.x
						data[i][2]=pos.y
						data[i][3]=pos.c			
						data[i].x=pos.x
						data[i].y=pos.y
						data[i].c=pos.c
					end
				end
				pos=nil
			end
			return n,data,0	
		else
			return nil,nil,2
		end	
	else					
		return nil,nil,err_net
	end	
end

function CCDPixelrecv(CamName)
	local   CamNo=GetParamNum(CamName)
	local 	CameraPara=CAM[CamNo]
	local	RecBuf={}
	local	err_net=0

	RecBuf,err_net=SysNetGet(CameraPara.netMode,NetDescribe[CamNo],CameraPara.blockMode,CameraPara.blockTime)
	
	if err_net==0 then 								--有数据更新且无错
		local n,data = GetCmmData(RecBuf,CameraPara.recvForm)	--数据处理	
		
		if data then
			return n,data,err_net	
		else
			return nil,nil,err_net
		end	
	else					
		return nil,nil,err_net
	end	
	
end

--[[
	函数名： CCDtrigger
	功能：	触发相机拍照
	输入：	CamName	:	视觉名，在UI配置时会生成
	可根据设置自动识别 网络触发orIO触发
]]--

function CCDtrigger(CamName)
	local   CamNo=GetParamNum(CamName)
	local 	CameraPara=CAM[CamNo]
	local	sta=0
	
	if CameraPara.visType ~= 2 then	
		if 	CameraPara.trigWay == 0 then			--0为IO触发
			DO(CameraPara.trigOutPort,1,"Time=50")	--打开50ms后关闭
		elseif CameraPara.trigWay == 1 then			--1为网络触发
			if CameraPara.calibType==1 and CameraPara.IsRobotCalib==0 and CameraPara.visType == 1 then	--发送坐标到视觉
				local pos,joint=Getpos()
				local buff,cpos
				pos,joint=Getpos()	
				cpos=joint.x+joint.y
				buff=string.format("%.3f,%.3f,%.3f,%d;",pos.x,pos.y,cpos,tonumber(CameraPara.trigForm))
		
				sta=SysNetSend(buff,CameraPara.netMode,NetDescribe[CamNo],CameraPara.ip,CameraPara.port)
			else 
				sta=SysNetSend(CameraPara.trigForm,CameraPara.netMode,NetDescribe[CamNo],CameraPara.ip,CameraPara.port)
			end
		end
	else
		sta=1
	end	
	return sta	
end

--[[
	函数名： AutoNine
	功能：	自动九点标定
	输入：	CamName	:	视觉名，在UI配置时会生成
			mark：		mark点的序号
			step：		偏移量，毫米为单位
			angle：		旋转偏移量，度为单位
			cal_type：	N点标定
			tn：		工具坐标系
]]--
function AutoNine(CamName,mark,step,angle,pixel,cal_type,tn)	
	
	local   CamNo=GetParamNum(CamName)
	local 	CameraPara=CAM[CamNo]
--	local 	ipPort={ipaton(CameraPara.ip),CameraPara.port}	--ip，port	
	local 	markPos = Point(mark)
	local	pos={}
	local	index={}
	local 	pos9={X(0),X(-step),Y(-step),X(step),X(step),Y(step),Y(step),
					X(-step),X(-step),C(angle),C(-angle*2)}
	local 	index9={5,8,9,6,3,2,1,4,7,51,52,
					61,62,63,64,65,66,61,62,63,64,65,66,61,62,63,64,65,66,67}	
	
	local 	pos16={X(0),XYZC(step/2,step/2,0,0),Y(-step),X(-step),X(-step),Y(-step),
			X(step),X(step),X(step),Y(step),Y(step),Y(step),X(-step),X(-step),X(-step),
			Y(-step),X(step),C(angle),C(-angle*2)}--17+2=19个点
	local 	index16={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,51,52,
					61,62,63,64,65,66,61,62,63,64,65,66,61,62,63,64,65,66,67}	
	local stepX=step
	local stepY=step				
	local 	pos25={X(0),X(-stepX),Y(-stepY),X(stepX),X(stepX),Y(stepY),Y(stepY),X(-stepX),X(-stepX),X(-stepX),
					Y(-stepY),Y(-stepY),Y(-stepY),X(stepX),X(stepX),X(stepX),X(stepX),
					Y(stepY),Y(stepY),Y(stepY),Y(stepY),X(-stepX),X(-stepX),X(-stepX),X(-stepX),
					C(angle),C(-angle*2)}--25+2=27个点，
	local 	index25={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,
					51,52,
					61,62,63,64,65,66,61,62,63,64,65,66,61,62,63,64,65,66,67}	

	local 	tool={x=0,y=0,z=0,c=0}
	local 	sum=0
	local 	err_net=0
	local 	RecBuf={}
	local 	flag=0
	local	angleC=0
	
	SetCalibData(CameraPara.stpOffset,CameraPara.angle)

	InitNet(CamName)
	Delay(100)

	if CameraPara.visType==2 then
		SetU(CameraPara.userCrd)
	else
		SetU(0)
	end
	SetT(0)
	sysrate(10)	--设置倍率
	Delay(100)
	MotOn()
	Delay(500)

	if cal_type==9 then
		sum=9+2+18+1
		pos=pos9
		index=index9
		print("自动9点标定",CamName,mark,step)
	elseif cal_type==16 then
		sum=17+2+18+1
		pos=pos16
		index=index16
		print("自动16点标定",CamName,mark,step)
	elseif cal_type==25 then
		sum=25+2+18+1
		pos=pos25
		index=index25
		print("自动25点标定",CamName,mark,step)
	else
		Error("auto cali error!")	
	end
	
	for i=1,sum do
		if flag==0 then
			markPos = markPos + pos[i]
			print("markPos x:",markPos.x,"  y:",markPos.y,"  z:",markPos.z,"  c:",markPos.c)
			MovP(markPos)
		else
			MovPR(AC,angleC)
		end
		
		Delay(1000)
		CCDtrigger(CamName)
		RecBuf,err_net=SysNetGet(CameraPara.netMode,NetDescribe[CamNo],0,0)

		local n,data = GetCmmData(RecBuf,CameraPara.recvForm)

		if data and data[1].x~=0 and data[1].y~=0 then
			if cal_type==9 then
				tool=VisNine(CameraPara.visType,index[i]-1,data[1].x,data[1].y,pixel,CameraPara.stepAng)
			elseif cal_type==16 then
				tool=VisSixteen(CameraPara.visType,index[i]-1,data[1].x,data[1].y,pixel,CameraPara.stepAng)
			elseif cal_type==25 then
				tool=Vis25(CameraPara.visType,index[i]-1,data[1].x,data[1].y,pixel,CameraPara.stepAng)
			else
				Error("auto cali error!")	
			end
			print(i,index[i]-1,data[1].x,data[1].y)
			--print("tool:",tool.x,tool.y,tool.z,tool.c)
		else 
			Error("didn't catch the point: ")
			return 0
		end
		
		if i==sum-2-18-1 then	--输入当前法兰位置
			markPos = Point(mark)
			MovP(Point(mark))
			print("自动九点标定完成！")
			Delay(1500)
			print("自动标定旋转中心",CamName,mark,angle)
			if cal_type==9 then
				tool=VisNine(CameraPara.visType,49,data[1].x,data[1].y,pixel,CameraPara.stepAng)
			elseif cal_type==16 then
				tool=VisSixteen(CameraPara.visType,49,data[1].x,data[1].y,pixel,CameraPara.stepAng)
			elseif cal_type==25 then
				tool=Vis25(CameraPara.visType,49,data[1].x,data[1].y,pixel,CameraPara.stepAng)
			else
				Error("auto cali error!")	
			end

		elseif i==sum-18-1 then
			markPos = Point(mark)
			MovP(Point(mark))
			Delay(500)
			if tn then
				WrT(tn,tool)
				SetT(tn)
			else
				WrT(CameraPara.camTCrd,tool)
				SetT(CameraPara.camTCrd)
			end
			print("旋转中心标定完成！")
			flag=1
			angleC=0
			Delay(500)
		elseif (i>=sum-18 and i<=sum-14) or (i>=sum-12 and i<=sum-8) or (i>=sum-6 and i<=sum-2) then
			angleC=CameraPara.stepAng
		elseif i==sum-1-6-6 then	
			MovPR(AC,-5*CameraPara.stepAng)	
			Delay(300)
			if tn then
				WrT(tn,tool)
			else
				WrT(CameraPara.camTCrd,tool)
			end
			flag=1
			print("高精度旋转中心标定1完成！")
			Delay(100)
			angleC=0
		elseif i==sum-1-6 then			
			MovPR(AC,-5*CameraPara.stepAng)	
			Delay(300)
			if tn then
				WrT(tn,tool)
			else
				WrT(CameraPara.camTCrd,tool)
			end
			flag=1
			print("高精度旋转中心标定2完成！")
			Delay(100)
			angleC=0
		elseif i==sum-1 then
			angleC=0
			Delay(500)
			SetT(0)
			markPos = Point(mark)
			MovP(Point(mark))
			Delay(100)
--[[			if tn then
				WrT(tn,tool)
			else
				WrT(CameraPara.camTCrd,tool)
			end		--]]
			print("高精度旋转中心标定3完成！")			
			Delay(100)
		elseif i==sum then
			flag=0
			if tn then
				WrT(tn,tool)
			else  
				WrT(CameraPara.camTCrd,tool)
			end
			print("总标定完成！")
			MotOff()
			Delay(100)
		end
	end
	pos=nil
end


function GetViewpos(CamName)
	local   CamNo=GetParamNum(CamName)
	local 	CameraPara=CAM[CamNo]

	InitNet(CamName)

	print("获得视觉坐标\n")
	CCDtrigger(CamName)
	local n,data=CCDrecv(CamName)
	if n and data[1].x and data[1].y and data[1].c then
		if data[1].x==0 and data[1].y==0 and data[1].c==0 then
			Error("获得视觉坐标失败\n")
		end
		publicwrite(0x102,data[1].x,"float")	
		publicwrite(0x104,data[1].y,"float")	
		publicwrite(0x106,data[1].c,"float")
		print("获得视觉坐标成功\n")	
	else
		Error("获得视觉坐标失败\n")
	end
end

function GetPixelpos(CamName)
	local   CamNo=GetParamNum(CamName)
	local 	CameraPara=CAM[CamNo]
	local   buff
	local	RecBuf={}
	local	err_net=0
	
	InitNet(CamName)

	print("获得视觉坐标\n")
	--[[buff=string.format("PIX,%s","0,0,0,0;")
	
	SendNet(CamName,buff)--]]
	if CameraPara.visType == 2 then
		if 	CameraPara.trigWay == 0 or CameraPara.trigWay == 2 then
			if CameraPara.netMode==3 then
				SendNet(CamName,"[#@$&]")
			end
			DO(CameraPara.trigOutPort,1,"Time=50")	--打开50ms后关闭
		end
	else
		if 	CameraPara.trigWay == 0 then			--0为IO触发
			if CameraPara.netMode==3 then
				SendNet(CamName,"[#@$&]")
			end
			DO(CameraPara.trigOutPort,1,"Time=50")	--打开50ms后关闭
		elseif CameraPara.trigWay == 1 then			--1为网络触发			
			SendNet(CamName,CameraPara.trigForm)
		end
	end
	
	RecBuf,err_net=ReadNet(CamName)
	if err_net==0 then								--有数据更新且无错
		SentPixelData(RecBuf)
	else
		Error("获取像素失败！")
	end
end

function VisAutoJ2(CamName,pt)
	InitNet(CamName)
	local camera_id=0
	print("VisAutoJ2 run\n")
    MotOn()
	SendNet(CamName,"[#@$&]")
	while true do		
		local pos,joint=Getpos()
		local cpos,buff
		local n,data=CCDrecv(CamName)
		if data[1].NO == "START" then
			camera_id = data[1].x
            buff=string.format("START_OK,0,0,0,%d;",camera_id)
			SendNet(CamName,buff)
		elseif	data[1].NO == "J2" then--第二轴标定
			for photo_pos = pt,pt+10 do
				MovP(photo_pos)
				Delay(200)  
				pos,joint=Getpos()	
				cpos=joint.x+joint.y
				buff=string.format("CAM,%.3f,%.3f,%.3f,%d;",pos.x,pos.y,cpos,camera_id)
				::PHOTO::	
				SendNet(CamName,buff)
				Delay(500)
				if photo_pos < pt+10 then
					local n,data=CCDrecv(CamName)
					if data then  --数据有效
						if data[1].x == 0 and data[1].y == 0 and data[1].c == 0 then
							goto PHOTO
						end
					else   --数据无效
						goto PHOTO
					end
				end
			end
            --break
		elseif  data[1].NO == "FINISH" then
			MotOff()
			Delay(100)
			return
		end
	end
end

function VisAutoClib(CamName,pt,toolNo)
	InitNet(CamName)
	local camera_id=0
	local ready_pos=Point(pt)
	print("run\n")
    MotOn()
	SendNet(CamName,"[#@$&]")
	while true do		
		local pos,joint=Getpos()
		local cpos,buff
		local n,data=CCDrecv(CamName)
		if data[1].NO == "START" then
			SetT(0)
			SetU(0)
			MovP(ready_pos,"Spd=10")
			camera_id = data[1].x	
            buff=string.format("START_OK,0,0,0,%d;",camera_id)    
		elseif data[1].NO == "J4" then  --第四轴或静止标定
			print( pos.x,pos.y,pos.c)
			pos.x=pos.x+data[1].x
			pos.y=pos.y+data[1].y
			pos.c=pos.c+data[1].c
			cpos=pos.c
			print( pos.x,pos.y,pos.c)
			MovP(pos,"Spd=10")
            buff=string.format("CAM,%.3f,%.3f,%.3f,%d;",pos.x,pos.y,cpos,camera_id)  
		elseif	data[1].NO == "J2" then--第二轴标定
			print( joint.x,joint.y,joint.c)	
			pos.x=pos.x+data[1].x
			pos.y=pos.y+data[1].y
			print( pos.x,pos.y,pos.c)
			MovP(pos,"Spd=10")  
			pos,joint=Getpos()	
			joint.y = joint.y+data[1].c
			print( joint.x,joint.y,joint.c)
			
			MovJ(J2,joint.y,"Spd=10")  
			pos,joint=Getpos()	
			cpos=joint.x+joint.y
            buff=string.format("CAM,%.3f,%.3f,%.3f,%d;",pos.x,pos.y,cpos,camera_id)
		elseif	data[1].NO == "TOOL1" then--九点标定，设置第一次计算的工具
			SetT(0)
			SetU(0)
			MovP(ready_pos,"Spd=10")
			Delay(100)	
			WrT(toolNo,data[1])
			SetT(toolNo)
            buff=string.format("TOOL1_OK,0,0,0,%d;",camera_id)
		elseif	data[1].NO == "TOOL2" then--九点标定，设置第二次计算的工具，并验证精度	
			SetT(0)
			SetU(0)
			MovP(ready_pos,"Spd=10")
			Delay(100)
			pos,joint=Getpos()
			buff=string.format("CAM,%.3f,%.3f,%.3f,%d;",pos.x,pos.y,pos.c,camera_id)	
			SendNet(CamName,buff)
			Delay(500)	
			WrT(toolNo,data[1])
			SetT(toolNo)
			pos,joint=Getpos()
            buff=string.format("TOOL2_OK,%.3f,%.3f,%.3f,%d;",pos.x,pos.y,pos.c,camera_id)
		elseif  data[1].NO == "FINISH" then
			MotOff()
			Delay(100)
			return
		end
        Delay(200)
	    SendNet(CamName,buff)
        Delay(500)
	end
end

--*****************************************************传送带相关函数*********************************************************

function DEG1(radian)
	return	((radian)*180.0/math.pi)
end
function RAD1(degree)	
	return ((degree)*math.pi/180.0)
end

--计算物件在单位圆上的角度
--输入：圆上一点，圆心，角度增量; 输出：起始角度，半径，目标位置
function syn_cal_angle_of_circle(pos,center)

	local theta1,R;
	local theta

	R=math.sqrt((pos.x-center.x)*(pos.x-center.x)+(pos.y-center.y)*(pos.y-center.y));
	theta1=math.acos((pos.x-center.x)/R);

	if (pos.x>=0 and pos.y>=0) then
		theta=DEG1(theta1);
	elseif (pos.x<=0 and pos.y>=0) then
		theta=DEG1(theta1);
	elseif (pos.x<0 and pos.y<0 ) then
		theta=DEG1(-theta1);
	elseif (pos.x>=0 and pos.y<=0) then
		theta=DEG1(-theta1);	
	end
	return theta;
end

--输入坐标，顺逆时针（0：顺，1：逆时针），圆心，左上点，左下点，右上点，右下点
function adt_determine_range_in_circle(pos,dir,center,pos1,pos2,pos3,pos4)

	local R1;--外圆半径
	local R2;--内圆半径
	local p1,p2={};
	local theta0,theta1,theta2;
	
	R1=(math.sqrt((pos1.x-center.x)*(pos1.x-center.x)+(pos1.y-center.y)*(pos1.y-center.y))
	   +math.sqrt((pos3.x-center.x)*(pos3.x-center.x)+(pos3.y-center.y)*(pos3.y-center.y)))/2;
	R2=(math.sqrt((pos2.x-center.x)*(pos2.x-center.x)+(pos2.y-center.y)*(pos2.y-center.y))
	   +math.sqrt((pos4.x-center.x)*(pos4.x-center.x)+(pos4.y-center.y)*(pos4.y-center.y)))/2;
	
	if ((pos.x-center.x)*(pos.x-center.x)+(pos.y-center.y)*(pos.y-center.y)-R1*R1 > 0) then
		return -1;
	end
	if ((pos.x-center.x)*(pos.x-center.x)+(pos.y-center.y)*(pos.y-center.y)-R2*R2 < 0) then
		return -1;
	end
	p1.x=(pos1.x+pos2.x)/2;	p1.y=(pos1.y+pos2.y)/2;
	p2.x=(pos3.x+pos4.x)/2;	p2.y=(pos3.y+pos4.y)/2;	
	
	theta1=syn_cal_angle_of_circle(p1,center);--左边点
	theta2=syn_cal_angle_of_circle(p2,center);--右边点
	theta0=syn_cal_angle_of_circle(pos,center);--当前点

	if dir==0 then	--顺时针
		if theta1<0 and theta2>0 then
			return -1;
		else	
			if(theta0>=theta1)		then print("shun,wei jin ru\n"); 	return 0;	--未进入
			elseif(theta0<=theta2)	then print("shun,chao chu\n"); 	return 2;	--超出
			elseif((theta0<theta1)and(theta0>theta2))then 				return 1;	--在抓取区
			else														return -1;	end
		end
	else			--逆时针
		if theta1<0 and theta2>0 then 
			return -1;	
		else	
			if(theta0<=theta2)		then print("ni,wei jin ru\n");	return 0;	--未进入
			elseif(theta0>=theta1)	then print("ni,chao chu\n");	return 2;	--超出
			elseif((theta0<theta1)and(theta0>theta2)) then			return 1;	--在抓取区
			else													return -1;	end
		end
	end
end


function syn_cal_realtime_position(pos,center,inc_theta)
local posc={}
local theta1,theta2,ori_theta
local R

	R=math.sqrt((pos.x-center.x)*(pos.x-center.x)+(pos.y-center.y)*(pos.y-center.y));
	theta1=math.acos((pos.x-center.x)/(R));
	theta2=math.asin((pos.y-center.y)/(R));
	if pos.x>=0 and pos.y>=0 then
		ori_theta=DEG1((theta1+theta2)/2)
	elseif pos.x<=0 and pos.y>=0 then
		ori_theta=DEG1(theta1)
	elseif pos.x<0 and pos.y<0 then
		ori_theta=DEG1(-theta1)
	elseif pos.x>=0 and pos.y<=0 then
		ori_theta=DEG1(theta2)
	end

	print("theta1:",theta1," theta2:",theta2)
	print("R:",R," ori_theta: ", ori_theta)

	posc.x=center.x+(R)*math.cos(RAD1(ori_theta+inc_theta));
	posc.y=center.y+(R)*math.sin(RAD1(ori_theta+inc_theta));
--	posc.c=posc.c+inc_theta;
	print("x:",posc.x," y:",posc.y," c:",posc.c)
	
	return posc
end



--[[
	函数名： CnvQueInit
	功能：	动态跟随初始化
	输入：	CnvName	:	视觉名，在UI配置时会生成
]]--


function CnvQueInit(CnvName)
	local CnvNo=GetParamNum(CnvName)
    local p=CAM[CnvNo].dynPara 
	local count = 1  
	excoderinit({p.portNo-1,
				 CAM[CnvNo].cdrType,
				 CAM[CnvNo].ratio,
				 CAM[CnvNo].revDir})
	SetDynParam({	
					p.CnvAble,					--是否打开		DSP
					p.CnvNo-1,					--传送带编号	DSP
					p.CnvType,					--传送带类型 	AR
					p.portNo-1,					--编码器号		AR
					p.synOptimal,				--是否选择最优路径
					CAM[CnvNo].trigWay,			--触发方式		DSP
					CAM[CnvNo].trigInPort,		--输入			DSP
					CAM[CnvNo].trigOutPort,		--输出			DSP
					p.viewRange,				--拍照间距		DSP
					
					p.syntime,					--同步时间		DSP
					p.sampleTime,				--采样周期		dsp
					p.posTime,					--位置时间补偿	暂未用
					p.pulseEq,					--脉冲当量		AR,DSP
					
					p.xLimitS,					--限位			AR,DSP	
					p.xLimitE,
					p.yLimitN,
					p.yLimitP,

					p.circleDir,						--方向	dsp
					p.circleCenter.x,p.circleCenter.y,	--圆心	dsp
					p.circlePt.x1,p.circlePt.y1,		--限位	AR,DSP
					p.circlePt.x3,p.circlePt.y3,
					p.circlePt.x2,p.circlePt.y2,
					p.circlePt.x4,p.circlePt.y4
				})
	
	SetDynCatch(1)				--启动传送带任务
	
	print(p.CnvNo-1,"号传送带初始化完成，共：",count,"条队列。")
end

 --输入参数：视觉号（即传送带参数），队列号（一个传送带下可多个队列），位置
function CnvQueAdd(CnvName,QueNo,pos)

local CnvNo=GetParamNum(CnvName)
local p=CAM[CnvNo].dynPara	
local data={x=0,y=0,z=0,c=0,h=0,no=0,pulse=0,coder=0,type=0,cnvno=0}--no:料号，pulse:编码器值,coder:M5/M6，type:传送带类型

	data.x		=pos.x	
	data.y		=pos.y
	data.z		=pos.z
	data.c		=pos.c
	data.h		=pos.h	
	data.no		=pos.no
	data.coder	=p.portNo 		--5,6编码器
	data.type	=p.CnvType		--0,1传送带类型，直线or圆形
	data.cnvno	=p.CnvNo		--传送带号码，只有1,2
	data.pulseEq=p.pulseEq		--脉冲当量
	data.distance=p.distance	--丢弃距离

	if p.mlCatch==0 then 						--多机，主机
		data.pulse=GetTriggerCoder(p.CnvNo-1)	--输入编码器号
--		print(data.pulse,p.CnvNo-1)
	else
		data.pulse=pos.pulse;					--多机，拍照时编码器值，从机
	end
	
	if (p.CnvType==0)and(data.y>p.yLimitN and data.y<p.yLimitP) then
--		print("p.CnvType:",p.CnvType,"data.y:",data.y)
		qpush(QueNo,data);
	elseif(p.CnvType==1) then	
		qpush(QueNo,data);
	end
end

function CnvQueGet(CnvName,QueNo)		--监控传送带物件位置 
local CnvNo=GetParamNum(CnvName)
local p=CAM[CnvNo].dynPara		
local temp_x,coder_dis;
local encoder;
local data={x=0,y=0,z=0,c=0,h=0,no=0,pulse=0,coder=0,type=0,cnvno=0}--no:料号，pulse:编码器值,coder:M5/M6，type:传送带类型 0直线，1圆弧	

	if qempty(QueNo)==0 then
		data = qfront(QueNo)
		encoder= encoderget(data.coder)		--获取M5,M6编码器值
--		print(encoder,data.pulse)
		if data.type==0 then 				--直线跟随		
			temp_x = data.x+(encoder - data.pulse) * p.pulseEq;  --计算编码器所走距离
--			print("x:",data.x,"temp_x",temp_x)
			if(data.y>p.yLimitN and data.y<p.yLimitP) then			
				if(temp_x > p.xLimitS and temp_x < p.xLimitE) then --进入抓取区				
					return 1,data;				
				elseif(temp_x < p.xLimitS) then 		--尚未进入抓取区				
					return nil,nil;				
				elseif(temp_x > p.xLimitE)	then		--超出抓取区									
					qpop(QueNo);				
					return 0,data;
				end			
			else--y超出抓取区			
				qpop(QueNo);
				return nil,nil;
			end
		else	--圆弧抓取范围判断 cjh 2017/9/16		
			local flag=0;
			local pos={x=0,y=0};
			
			pos.x=data.x;
			pos.y=data.y;
			coder_dis = (encoder - data.pulse) * p.pulseEq;
			if p.circleDir==0	then coder_dis=-coder_dis; end
			
			pos=syn_cal_realtime_position(pos,p.circleCenter,coder_dis);
			flag=adt_determine_range_in_circle(pos,p.circleDir,p.circleCenter,
											p.LimitLeftUp,p.LimitLeftDown,
											p.LimitRightUp,p.LimitRightDown);
			if		flag==0	then return nil,nil;	--未进入
			elseif	flag==1	then return 1,data;		--在抓取区
			elseif	flag==2	then					--超出		
				qpop(QueNo);				
				return 0,data;		
			elseif flag==-1 then					--不在圆内		
				qpop(QueNo);
				return nil,nil;
			end
		end	
	else
		return nil,nil;
	end
end

function CnvQueGet1(CnvName,QueNo)		--监控传送带物件位置 
local CnvNo=GetParamNum(CnvName)
local p=CAM[CnvNo].dynPara		
local temp_x,coder_dis;
local encoder;
local data={x=0,y=0,z=0,c=0,h=0,no=0,pulse=0,coder=0,type=0,cnvno=0}--no:料号，pulse:编码器值,coder:M5/M6，type:传送带类型 0直线，1圆弧	

	if qempty(QueNo)==0 then
		data = qfront(QueNo)
		encoder= encoderget(data.coder)		--获取M5,M6编码器值
--		print(encoder,data.pulse)
		if data.type==0 then 				--直线跟随		
			temp_x = data.x+(encoder - data.pulse) * p.pulseEq;  --计算编码器所走距离
--			print("x:",data.x,"temp_x",temp_x)
			if(data.y>p.yLimitN and data.y<p.yLimitP) then			
				if(temp_x > p.xLimitS and temp_x < p.xLimitE) then --进入抓取区				
					return 1,data;				
				elseif(temp_x < p.xLimitS) then 		--尚未进入抓取区				
					return 1,data;					
				elseif(temp_x > p.xLimitE)	then		--超出抓取区									
					qpop(QueNo);				
					return 0,data;
				end			
			else--y超出抓取区			
				qpop(QueNo);
				return nil,nil;
			end
		else	--圆弧抓取范围判断 cjh 2017/9/16		
			local flag=0;
			local pos={x=0,y=0};
			
			pos.x=data.x;
			pos.y=data.y;
			coder_dis = (encoder - data.pulse) * p.pulseEq;
			if p.circleDir==0	then coder_dis=-coder_dis; end
			
			pos=syn_cal_realtime_position(pos,p.circleCenter,coder_dis);
			flag=adt_determine_range_in_circle(pos,p.circleDir,p.circleCenter,
											p.LimitLeftUp,p.LimitLeftDown,
											p.LimitRightUp,p.LimitRightDown);
			if		flag==0	then return nil,nil;	--未进入
			elseif	flag==1	then return 1,data;		--在抓取区
			elseif	flag==2	then					--超出		
				qpop(QueNo);				
				return 0,data;		
			elseif flag==-1 then					--不在圆内		
				qpop(QueNo);
				return nil,nil;
			end
		end	
	else
		return nil,nil;
	end
end


function CnvQueDel(CnvName,QueNo)		
	qpop(QueNo)	
end

function MissQueAdd(data)		
	--qpush(100,data);
	print("miss queue add!")
end

function CnvSynCatch(pos,a,b,c)	
local p=CAM[pos.cnvno].dynPara	
local data={}
local sta=0
	if pos.h==nil then
		local cart,joint=Getpos() --获取当前手系
		pos.h=cart.h
	end
	data[1]=pos.x		--位置
	data[2]=pos.y		
	data[3]=pos.z
	data[4]=pos.c
	data[5]=pos.h
--	data[5]=pos.coder-5	--编码器号、传送带号
	data[6]=pos.cnvno-1
	data[7]=pos.pulse	--触发拍照时编码器值	
	data[8]=p.xLimitS	
	data[9]=p.xLimitE	
--	data[5]=pos.no		--料号（也可做队列号判定）
--	data[6]=pos.pulse	--触发拍照时编码器值
--	data[7]=pos.coder	--编码器号、传送带号
--	data[8]=pos.type	--传送带类型
	if a==nil or b==nil or c==nil then
		sta=SetCatch(data)
	else
		sta=SetCatch(data,a,b,c)
	end
--	print("synsta = ",sta)
	return sta
end

function CnvFastCatch(pos,a,b,c)
--local CnvNo=GetParamNum(CnvName)
local p=CAM[pos.cnvno].dynPara	
local data={}
local sta=0
	if pos.h==nil then
		local cart,joint=Getpos() --获取当前手系
		pos.h=cart.h
	end
	data[1]=pos.x		
	data[2]=pos.y		
	data[3]=pos.z
	data[4]=pos.c
	data[5]=pos.h
	data[6]=pos.cnvno-1
--	data[5]=pos.coder-5	--编码器号、传送带号
	data[7]=pos.pulse	--触发拍照时编码器值	
	data[8]=p.xLimitS	
	data[9]=p.xLimitE	
--	data[5]=pos.no		--料号（也可做队列号判定）
--	data[6]=pos.pulse	--触发拍照时编码器值
--	data[7]=pos.coder	--编码器号、传送带号
--	data[8]=pos.type	--传送带类型	
	if a==nil or b==nil or c==nil then
		sta=FastCatch(data)
	else
		sta=FastCatch(data,a,b,c)
	end	
--	print("faststa = ",sta)
	return sta
end
